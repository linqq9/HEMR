import sys
import numpy


def cmp_result(label, rec):
    dist_mat = numpy.zeros((len(label) + 1, len(rec) + 1), dtype='int32')
    dist_mat[0, :] = range(len(rec) + 1)
    dist_mat[:, 0] = range(len(label) + 1)
    for i in range(1, len(label) + 1):
        for j in range(1, len(rec) + 1):
            hit_score = dist_mat[i - 1, j - 1] + (label[i - 1] != rec[j - 1])
            ins_score = dist_mat[i, j - 1] + 1
            del_score = dist_mat[i - 1, j] + 1
            dist_mat[i, j] = min(hit_score, ins_score, del_score)

    dist = dist_mat[len(label), len(rec)]
    return dist, len(label)

def match(val1,val2):
    l=min(len(val1),len(val2))
    err=0
    for i in range(l):              
        if val1[i]!=val2[i]:
            err+=1
    err+=max(len(val1),len(val2))-min(len(val1),len(val2))
    return err
def process(recfile, labelfile, resultfile):
    total_dist = 0
    total_label = 0
    total_line = 0
    total_line_rec = 0
    total_line_rec1 = 0
    total_line_rec2 = 0
    total_line_rec3 = 0
    rec_mat = {}
    label_mat = {}
    with open(recfile) as f_rec:
        for line in f_rec:
            tmp = line.split()
            key = tmp[0]
            latex = tmp[1:]
            rec_mat[key] = latex
    with open(labelfile) as f_label:
        for line in f_label:
            tmp = line.split()
            key = tmp[0]
            latex = tmp[1:]
            label_mat[key] = latex
    for key_rec in rec_mat:
        label = label_mat[key_rec]
        rec = rec_mat[key_rec]
        dist, llen = cmp_result(label, rec)
        total_dist += dist
        total_label += llen
        total_line += 1
        if dist == 0:
            total_line_rec += 1
        if dist <=1:
            total_line_rec1 += 1
        if dist <=2:
            total_line_rec2 += 1
        if dist <=3:
            total_line_rec3 += 1
    wer = float(total_dist) / total_label
    err1=float(total_line_rec1) / total_line
    err2=float(total_line_rec2) / total_line
    err3=float(total_line_rec3) / total_line
    sacc = float(total_line_rec) / total_line
    
    
    print(recfile)
    print('wer:',wer)
    print('sacc:',sacc)

    f_result = open(resultfile, 'w+')
    f_result.write('WER {}\n'.format(wer))
    f_result.write('ExpRate {}\n'.format(sacc))
    
    
    total_label = 0
    acc=0
    err1=0
    err2=0
    err3=0

    rec_mat = {}
    label_mat = {}
    with open(recfile) as f_rec:
        for line in f_rec:
            tmp = line.split()
            key = tmp[0]
            latex = tmp[1:]
            rec_mat[key] = latex
    with open(labelfile) as f_label:
        for line in f_label:
            tmp = line.split()
            key = tmp[0]
            latex = tmp[1:]
            label_mat[key] = latex
    
    for k1 in  rec_mat:
        label=label_mat[k1]
        res=rec_mat[k1]
        total_label+=1
        d=match(res,label)
        if d==0:
            acc+=1
        if d<=1:
            err1+=1
            
        if d<=2:
            err2+=1
        if d<=3:
            err3+=1
            
    print('exprate',acc/total_label)
    print('err1',err1/total_label)
    print('err2',err2/total_label)
    print('err3',err2/total_label)
    f_result.write('err1 {}\n'.format(err1/total_label))
    f_result.write('err2 {}\n'.format(err2/total_label))
    f_result.write('err3 {}\n'.format(err3/total_label))
    
    
    
    
    
    
    f_result.close()


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print('compute-wer.py recfile labelfile resultfile')
        sys.exit(0)
    process(sys.argv[1], sys.argv[2], sys.argv[3])
